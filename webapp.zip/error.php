<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Nana cafe</title>
<style type="text/css">
<!--
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
-->
</style></head>

<body>
<div style="text-align:center; font-family:Arial, Helvetica, sans-serif; font-size:36px; font-weight:bold;">
  <a href="index.php">You must login<br />
before you can access this page Thank you</a></div>
<div style="text-align:center; font-family:Arial, Helvetica, sans-serif; font-size:9px; font-weight:bold;">
( click the text above to go back to the main page )
</div>
</body>
</html>
